"""File to handle reading student information from sample file"""
import os

import openpyxl
from PIL import Image

from student_sample import students


def read_info(student_id):
    if student_id in students:
        return student_id, students[student_id]
    return None


def convert_and_reshape_image(file_name):
    image = Image.open(file_name,)
    image = image.resize((250, 250))
    image.save(os.path.join(os.getcwd(), 'assets', 'reshape.png'), format='png')
    return os.path.join(os.getcwd(), 'assets', 'reshape.png')


def mark_exam(questions, answers):
    """this function handle marking of exams after submission"""
    score = 10
    for key in answers:
        if questions[str(key)]['correct'] == answers[key].lower():
            score += 2
        else:
            pass

    path = os.path.join(os.getcwd(), 'assets', 'result', 'result.xlsx')
    if os.path.exists(path):
        work_book = openpyxl.load_workbook(path)
        work_sheet = work_book['Sheet1']
    else:
        work_book = openpyxl.Workbook()
        work_sheet = work_book.create_sheet('Sheet1')

    work_sheet.append((score,))
    work_book.save(path)
    work_book.close()
    print(score)
    return score

# mark_exam('', '')