questions = {
    '1': {
        'question': 'Define a computer',
        'options': {
            'A': '''An electronic machine which accept data as input, process it and produce out''',
            'B': 'A mechanical machine',
            'C': 'None of the above',
            'D': 'A typwriter in practice'
        },
        'correct': 'a'
    },
    '2': {
        'question': 'Which of the following is an input device?p',
        'options': {
            'A': 'Speaker',
            'B': 'Monitor',
            'C': 'Mouse',
            'D': 'Printer'
        },
        'correct': 'c'
    },
    '3': {
        'question': 'What year was internet created?',
        'options': {
            'A': '1970',
            'B': '1990',
            'C': '1978',
            'D': '1960'
        },
        'correct': 'c'
    },
    '4': {
        'question': 'How many types of Network have we?',
        'options': {
            'A': 'Three(3)',
            'B': 'Two(2)',
            'C': 'Five(5)',
            'D': 'One(1)'
        },
        'correct': 'a'
    },
    '5': {
        'question': 'Who was the first programmer?',
        'options': {
            'A': 'Charles Barbage',
            'B': 'Ada Lovelace',
            'C': 'Thompson Hon',
            'D': 'Dama Michael'
        },
        'correct': 'b'
    },
    '6': {
        'question': 'Define a computer',
        'options': {
            'A': '''An electronic machine which accept data as input, process it and produce out''',
            'B': 'A mechanical machine',
            'C': 'None of the above',
            'D': 'A typwriter in practice'
        },
        'correct': 'a'
    },
    '7': {
        'question': 'Which of the following is an input device?p',
        'options': {
            'A': 'Speaker',
            'B': 'Monitor',
            'C': 'Mouse',
            'D': 'Printer'
        },
        'correct': 'c'
    },
    '8': {
        'question': 'What year was internet created?',
        'options': {
            'A': '1970',
            'B': '1990',
            'C': '1978',
            'D': '1960'
        },
        'correct': 'c'
    },
    '9': {
        'question': 'How many types of Network have we?',
        'options': {
            'A': 'Three(3)',
            'B': 'Two(2)',
            'C': 'Five(5)',
            'D': 'One(1)'
        },
        'correct': 'a'
    },
    '10': {
        'question': 'Who was the first programmer?',
        'options': {
            'A': 'Charles Barbage',
            'B': 'Ada Lovelace',
            'C': 'Thompson Hon',
            'D': 'Dama Michael'
        },
        'correct': 'b'
    },
    '11': {
        'question': 'Define a computer',
        'options': {
            'A': '''An electronic machine which accept data as input, process it and produce out''',
            'B': 'A mechanical machine',
            'C': 'None of the above',
            'D': 'A typwriter in practice'
        },
        'correct': 'a'
    },
    '12': {
        'question': 'Which of the following is an input device?p',
        'options': {
            'A': 'Speaker',
            'B': 'Monitor',
            'C': 'Mouse',
            'D': 'Printer'
        },
        'correct': 'c'
    },
    '13': {
        'question': 'What year was internet created?',
        'options': {
            'A': '1970',
            'B': '1990',
            'C': '1978',
            'D': '1960'
        },
        'correct': 'c'
    },
    '14': {
        'question': 'How many types of Network have we?',
        'options': {
            'A': 'Three(3)',
            'B': 'Two(2)',
            'C': 'Five(5)',
            'D': 'One(1)'
        },
        'correct': 'a'
    },
    '15': {
        'question': 'Who was the first programmer?',
        'options': {
            'A': 'Charles Barbage',
            'B': 'Ada Lovelace',
            'C': 'Thompson Hon',
            'D': 'Dama Michael'
        },
        'correct': 'b'
    },
    '16': {
        'question': 'Define a computer',
        'options': {
            'A': '''An electronic machine which accept data as input, process it and produce out''',
            'B': 'A mechanical machine',
            'C': 'None of the above',
            'D': 'A typwriter in practice'
        },
        'correct': 'a'
    },
    '17': {
        'question': 'Which of the following is an input device?p',
        'options': {
            'A': 'Speaker',
            'B': 'Monitor',
            'C': 'Mouse',
            'D': 'Printer'
        },
        'correct': 'c'
    },
    '18': {
        'question': 'What year was internet created?',
        'options': {
            'A': '1970',
            'B': '1990',
            'C': '1978',
            'D': '1960'
        },
        'correct': 'c'
    },
    '19': {
        'question': 'How many types of Network have we?',
        'options': {
            'A': 'Three(3)',
            'B': 'Two(2)',
            'C': 'Five(5)',
            'D': 'One(1)'
        },
        'correct': 'a'
    },
    '20': {
        'question': 'Who was the first programmer?',
        'options': {
            'A': 'Charles Barbage',
            'B': 'Ada Lovelace',
            'C': 'Thompson Hon',
            'D': 'Dama Michael'
        },
        'correct': 'b'
    }
}
