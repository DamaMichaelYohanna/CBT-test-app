import os
import threading
import time
import tkinter as tk
import tkinter.messagebox as mbox
from tkinter.ttk import Frame
from tkinter import ttk

import Pmw

import middle_wares
from questions import questions


class MainUi(Frame):
    init_id: int

    def __init__(self, parent):
        Frame.__init__(self, parent)

        self.test_icon = None
        self.study_icon = None
        self.init_id = 1
        self.parent = parent
        self.parent.title('CBT Application')
        self.parent['bg'] = '#f1f1f1'
        # self.parent.resizable(0, 0)
        self.parent.iconphoto(False, tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                                     'assets',
                                                                     'icon.png')))
        # self.parent.iconname('CBT software')
        self.balloon = Pmw.Balloon(self.parent)
        # frame to hold the headings

        self.answers_dict = {}
        # create an int variable to store value of check box and time
        self.var = tk.StringVar(value='.')
        self.hours = tk.IntVar(value=0)
        self.minutes = tk.IntVar(value=0)
        self.seconds = tk.IntVar(value=0)
        # signal to keep time thread running
        self.terminate = False
        # variable to hold color for time during test
        self.warning_color = 'black'
        # images goes here
        self.school_logo = tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                           'assets',
                                                           'nsuk.png'))
        self.school_logo = self.school_logo.subsample(2, 2)
        self.login_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                          'assets',
                                                          'login.png'))
        self.login_icon = self.login_icon.subsample(1, 1)
        self.ict_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                        'assets',
                                                        'ict.png'))
        self.ict_icon = self.ict_icon.subsample(2, 2)

        self.clock_image = tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                           'assets',
                                                           'clock.png')
                                         )
        self.clock_image = self.clock_image.subsample(2, 2)
        self.subject_image = tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                             'assets',
                                                             'subject2.png'))
        self.subject_image = self.subject_image.subsample(3, 3)
        self.warn_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                         'assets',
                                                         'error.png'))
        self.warn_icon = self.warn_icon.subsample(3, 3)
        self.bullet_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                           'assets',
                                                           'bullet.png'))
        self.bullet_icon = self.bullet_icon.subsample(6, 6)
        self.me = tk.PhotoImage(file=os.path.join(os.getcwd(),
                                                  'assets',
                                                  'me.png'))
        self.me = self.me.subsample(8, 8)
        # self.test_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
        #                                                  'assets',
        #                                                  'test.png'))
        # self.test_icon = self.test_icon.subsample(4, 4)
        # self.study_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
        #                                                   'assets',
        #                                                   'study.png'))
        # self.study_icon = self.study_icon.subsample(4, 4)
        # self.progress_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
        #                                                      'assets',
        #                                                      'progress.png'))
        # self.progress_icon = self.progress_icon.subsample(3, 3)
        #
        # self.message_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
        #                                                     'assets',
        #                                                     'message.png'))
        # self.message_icon = self.message_icon.subsample(1, 1)
        # self.syllabus_icon = tk.PhotoImage(file=os.path.join(os.getcwd(),
        #                                                      'assets',
        #                                                      'subject1.png'))
        # self.syllabus__icon = self.syllabus_icon.subsample(1, 1)

        # create the heading and the body of the application
        self.heading_frame = tk.Frame(self.parent)  # frame for the heading
        self.heading_frame.grid(sticky='we')
        # display description
        tk.Label(self.heading_frame,
                 text='Nasarawa State University, Keffi CBT Software',
                 fg='#336699',
                 font='matura 30').grid(ipady=8, padx=25, sticky='w', column=0, row=0)
        tk.Label(self.heading_frame, image=self.school_logo,
                 ).grid(row=0, column=1, padx=5)
        tk.Label(self.heading_frame, image=self.ict_icon,
                 ).grid(row=0, column=2, padx=5)
        ttk.Separator(self.heading_frame).grid(row=2, columnspan=3, sticky='we')

        # frame to hold the body of the program
        self.body = tk.Frame(self.parent, bg='#f1f1f1')
        self.body.grid(sticky='we')

        self.login_page()

    # call back function for the top menus
    @staticmethod
    def quit_button_call_back():
        if mbox.askokcancel(title='Warning!',
                            message='Are you sure you want to close the program?'):
            root.destroy()
        else:
            pass

    def list_courses_call_back(self):
        """call back function for the take test button"""

    def marking_call_back(self):
        print('i was called')
        """call the marking function, passing the questions and the answers"""
        middle_wares.mark_exam(questions=questions, answers=self.answers_dict)

    def take_exam_call_back(self):
        if self.terminate:
            self.terminate = False
        self.init_id = 1
        self.answers_dict = {}
        self.stop_threads = threading.Event()
        self.thread = threading.Thread(target=self.timer)
        self.thread.setDaemon(daemonic=True)
        self.question_display()
        self.instruction_frame.destroy()
        self.thread.start()

    def exam_submit_call_back(self, reason):
        if reason == 'time up':
            self.main_frame.destroy()
            self.stop_threads.set()
            self.terminate = True
            self.login_page()
        elif reason == 'exhaust':
            print('i was called')
            self.main_frame.destroy()
            self.stop_threads.set()
            self.terminate = True
            self.login_page()
        else:
            if mbox.askokcancel(title='Alert',
                                message='Are you sure you want to submit?'):
                self.main_frame.destroy()
                self.stop_threads.set()
                self.terminate = True
                print('threading is stopped')
                self.login_page()
                # self.thread.join()
            else:
                pass

        self.marking_call_back()

    def timer(self):
        minutes = 5
        seconds = 60
        counter = 0
        while counter <= minutes and not self.stop_threads.is_set():
            seconds -= 1
            self.seconds.set(seconds)
            self.minutes.set(minutes)
            if seconds == 0 and minutes > 0:
                minutes -= 1
                seconds = 60
            elif seconds == 0 and minutes == 0:
                break
            # set time color to red when time reaches 2 minutes
            if minutes <= 2:
                self.warning_color = 'red'
            time.sleep(1)
        if not self.terminate:
            if mbox.showwarning(title='Time up', message='Your time is up!'):
                print('clicked')
                self.exam_submit_call_back('time up')
            else:
                print('passed')

    def change_question(self, x):
        """ method to use for changing the questions from question index"""
        self.init_id = x
        self.main_frame.destroy()
        self.question_display()

    def next_question(self):
        """ method for navigating to the next question"""
        index = self.init_id  # get the index of the current question
        var = self.var.get()  # get the selected option from the var
        if index in self.answers_dict.keys():  # check option already exist
            if var != '.':  # if it not an empty string, update with new string
                self.answers_dict[index] = var
            # if not empty just pass
        else:  # if key does not exist, add it into the answer dictionary
            self.answers_dict[index] = var
        # increment the question id to change the question
        self.init_id += 1
        self.var.set('.')  # set the selected option to empty
        # check to know if questions are exhausted.
        try:
            f'{questions[f"{self.init_id}"]["question"]}'
        except KeyError:
            if mbox.askyesno(title='Notice',
                             message='You have exhausted your questions. Do you want to submit?'):
                self.exam_submit_call_back('exhaust')
            else:
                pass
            self.init_id -= 1
        else:
            self.main_frame.destroy()
            self.question_display()  # redraw the screen to display changes

    def prev_question(self):
        """ method to navigate to the previous question"""
        self.init_id -= 1  # decrement by one to go to the previous question
        # self.main_frame.destroy()
        self.main_frame.destroy()
        self.question_display()  # redraw the screen to display the update

    def login_page(self):
        """method to show the login page"""

        def validate_credentials(_):
            """function to validate user input"""
            user = username.get()  # get username
            if user == '':  # check if fields are not empty
                mbox.showerror('Error', "field can't be empty")
            else:
                # check if student is in list

                user = middle_wares.read_info(user)  # grab the return id
                if user:  # if record was returned
                    self.matric = user[0]
                    self.photo = tk.PhotoImage(
                        file=middle_wares.convert_and_reshape_image(user[1]['image']))
                    self.detail = user[1]
                    print(self.matric, self.detail, self.photo)
                    # self.user_id = user
                    # show success message
                    mbox.showinfo('Success', 'Validation Successful!')
                    # destroy the login page
                    login_frame.destroy()
                    # launch the home pag
                    self.instruction_page()
                else:  # if id was not returned
                    # show error message
                    mbox.showerror(
                        'Failed',
                        'Login Failed! Check credentials and try again.'
                    )

        login_frame = tk.Frame(self.body, bg='white', relief='groove', bd=2, )
        login_frame.grid(padx=486, pady=128)
        login_frame.bind('KeyPress', validate_credentials)
        logo = tk.Label(login_frame, image=self.login_icon, bg='white', )
        logo.grid(row=0, column=0)
        ttk.Separator(login_frame).grid(sticky='we', padx=10)
        # show some description using the label frame which provide border
        # -------------------------------------
        label_frame = tk.Frame(login_frame, bg='white')
        label_frame.grid(row=3, padx=10, pady=15, )
        # ----------------------------------------
        # label for username and the username entry field
        username_label = tk.Label(label_frame, text='Matriculation Number', bg='white')
        username_label.grid(pady=5, padx=15)
        username = tk.Entry(label_frame, font='matura 17', highlightthickness=0,
                            width=20, bg='#f5f5f5', relief='flat', fg='#336699')
        username.grid(pady=10, sticky='we', ipadx=5)
        username.focus()  # give focus to the input area
        username.bind('<Return>', validate_credentials)
        submit = tk.Button(label_frame,
                           text='Validate Credential', width=19, bg='#336699',
                           font='matura 17', fg='white', activebackground='#336688',
                           highlightbackground='#00BB99',
                           activeforeground='#FFFFCC',
                           command=lambda _='': validate_credentials(_))
        submit.grid(pady=15, sticky='we')
        # create a small frame to hold the description and button for
        # creating new credentials
        # ==========================================================

    def instruction_page(self):
        """method to show the instruction page before taking exam"""

        def back_button_call_back():
            """call back for the back button """
            self.instruction_frame.destroy()
            self.login_page()

        def take_exams_call_back():
            """call back to the take exams button"""
            self.take_exam_call_back()

        self.instruction_frame = tk.Frame(self.body)
        self.instruction_frame.grid(pady=10)
        instruction_list = [
            'Your Exams is to last for an hour and thirty minutes. 1h:30min',
            'Carefully go through the questions and their respective options',
            'Select the the option you think is correct by clicking the check button',
            'Click on the Next&Save button to save and go to the next question',
            'Use the previous button to go back to the previous question',
            'When done, click on the submit button to submit.',
            'Remember to work with your time. Good luck',
        ]
        # left side to show instructions
        left_frame = tk.Frame(self.instruction_frame, bg='white')
        left_frame.grid(row=0, column=0, )

        mini_frame = tk.Frame(left_frame, bg='#f1f1f1')
        mini_frame.grid(row=0, column=0, columnspan=2, sticky='we')
        tk.Label(mini_frame,
                 text='Instruction', fg='red', bg='#f1f1f1',
                 font='helvetic 21').grid(row=0, column=1)
        tk.Label(mini_frame, image=self.warn_icon, bg='#f1f1f1').grid(row=0, column=0)
        tk.Label(mini_frame)
        ttk.Separator(mini_frame).grid(sticky='ewe', row=1, column=0, columnspan=3)
        for index, instruction in enumerate(instruction_list):
            small_frame = tk.Frame(left_frame, bg='white')
            small_frame.grid(row=index + 1, column=0, sticky='wwe', padx=10)
            tk.Label(small_frame, bg='white',
                     image=self.bullet_icon).grid(row=0, column=0, padx=10)
            tk.Label(
                small_frame, bg='white',
                text=instruction,
                font='helvetic 12').grid(row=0, column=1, sticky='w', pady=15)

        # right side to show the profile
        right_frame = tk.Frame(self.instruction_frame, )
        right_frame.grid(row=0, column=1, sticky='ns', padx=13, pady=5)
        tk.Label(right_frame, text='Profile', width=20,
                 font='matura 18').grid(columnspan=2)
        ttk.Separator(right_frame).grid(sticky='we', columnspan=2)
        tk.Label(right_frame, image=self.photo, bd=2, relief='groove').grid(row=3, column=0)
        info_frame = tk.Frame(right_frame, bg='#f9f9f9')
        info_frame.grid(row=3, column=1, sticky='ns', )
        tk.Label(info_frame, text=f'{self.matric}', font='matura 15',
                 bg='#f9f9f9').grid()
        ttk.Separator(info_frame).grid(sticky='we', )
        tk.Label(info_frame, text=f'Level:{self.detail["level"]}', bg='#f9f9f9').grid(sticky='w')
        tk.Label(info_frame, text=f'Address:{self.detail["address"]}'[:23] + '...',
                 bg='#f9f9f9').grid(stick='w')
        # draw horizontal line
        ttk.Separator(right_frame).grid(sticky='we', columnspan=2, pady=15)
        # take exams button
        tk.Button(right_frame, text='Start Examination', bg='#336699',
                  fg='white', font='helvetica 15', command=take_exams_call_back
                  ).grid(pady=20, row=5, column=0)
        # back button
        tk.Button(right_frame, text='Go Back', bg='#336699', fg='white',
                  font='helvetica 15', command=back_button_call_back
                  ).grid(pady=20, row=5, column=1)
        ttk.Separator(self.instruction_frame).grid(sticky='we', columnspan=2, )
        tk.Label(self.instruction_frame,
                 text='Shown Examination Malpractice. Good Luck!', bg='#f1f1f1',
                 font='matura 18', fg='red', ).grid(stick='we', columnspan=2, pady=20)

    def question_display(self):
        """Method to display the main question screen"""

        self.main_frame = tk.Frame(self.body, )  # main frame
        self.main_frame.grid(row=0, column=0, pady=10, padx=15, ipady=2)

        left_frame = tk.Frame(self.main_frame, bg='white')  # frame for left component
        left_frame.grid(row=0, column=0, sticky='we')
        # label frame for showing the subject
        subject_frame = tk.ttk.LabelFrame(left_frame, text='Subject')
        subject_frame.grid(row=0, column=0, )
        # show the subject icon
        subject_icon = tk.Label(subject_frame, image=self.subject_image)
        subject_icon.grid(row=0, column=0, padx=7)
        # show the subject name
        subject_label = tk.Label(subject_frame, text='Compiler Construction',
                                 bg='#3399CC', fg='white')
        subject_label.grid(row=0, column=1, ipady=5, ipadx=5, padx=10, pady=10)
        # add a horizontal space to extend width of the label frame
        space = tk.Label(subject_frame, width=65, padx=2)
        space.grid(row=0, column=2, )
        # display the question number
        question_number = tk.Label(left_frame, text=f'Question number: {self.init_id}',
                                   bg='white')
        question_number.grid(sticky='w', pady=10, )
        # draw a horizontal line
        sep = tk.ttk.Separator(left_frame, )
        sep.grid(sticky='we')
        # here come the question
        question = tk.Label(left_frame,
                            text=f'{questions[f"{self.init_id}"]["question"]}',
                            font='matura 12', bg='white', )
        question.grid(row=4, column=0, columnspan=1, sticky='w')  # display questions
        counter = 1  # set counter for griding the options
        # frame to hold the options for each question
        option_frame = tk.Frame(left_frame, bg='white')  # display the options
        option_frame.grid(pady=30, sticky='w')
        #  loop through the option and display the option and value
        for text, value in questions[f"{self.init_id}"]["options"].items():
            radio = tk.Radiobutton(option_frame, text=text,
                                   value=text, variable=self.var, bg='white',
                                   font='helvetica 11', highlightthickness=0,
                                   cursor='hand2',
                                   activebackground='white')
            radio.grid(row=counter, column=0, sticky='w')  # grid radio button
            #  display the options
            option_value = tk.Label(option_frame, text=value,
                                    font='helvetica 11', bg='white')
            option_value.grid(row=counter, column=1, sticky='w', padx=5, pady=6)
            counter += 1  # increment counter
        # var.set(3)
        # create a vertical white space
        tk.Label(left_frame, height=9, bg='white').grid(pady=4)
        # draw a horizontal line
        tk.ttk.Separator(left_frame).grid(sticky='we')
        # create a small frame
        nav_frame = tk.Frame(left_frame, bg='white', )  # create navigation frame
        nav_frame.grid()
        # draw a horizontal line before the previous, next and submit button
        ttk.Separator(left_frame, ).grid(sticky='we')
        # previous button goes here
        prev_button = tk.Button(nav_frame, text='Previews', font='helvetica 12',
                                bg='#3399CC', command=self.prev_question)
        prev_button.grid(row=0, column=0, padx=10, )  # add previous button
        # Next and save button goes here
        next_button = tk.Button(nav_frame, text='Save & Next', fg='white',
                                font='helvetica 12',
                                bg='#336699', command=self.next_question)
        next_button.grid(row=0, column=1, padx=3)  # add next button
        # add a space between buttons
        space = tk.Label(nav_frame, width=50, bg='white')
        space.grid(row=0, column=2)
        # submit button goes here
        submit_button = tk.Button(nav_frame, text='Submit', fg='white',
                                  font='helvetica 12', bg='#3399CC',
                                  command=lambda x='Done': self.exam_submit_call_back(x))
        submit_button.grid(row=0, column=3, padx=10, )  # add submit button

        # ------------------------------------------------------------------
        # right side to display list of questions
        right_frame = tk.Frame(self.main_frame, bg='white', bd=4, relief='ridge')  # frame for right component
        right_frame.grid(row=0, column=1, sticky='ns')
        time_section_frame = tk.Frame(right_frame, bg='white')
        time_section_frame.grid(padx=10, pady=10)
        time_icon = tk.Label(time_section_frame, image=self.clock_image, bg='white')
        time_icon.grid(column=0, row=0)
        # big frame to hold the time excluding the clock icon
        time_body_frame = tk.Frame(time_section_frame, bg='white')
        time_body_frame.grid(column=1, row=0)
        time_label = tk.Label(time_body_frame, text='Time Left',
                              font='matura 16', bg='white')
        time_label.grid(ipadx=4, column=0, row=0)
        # frame to hold the minutes and seconds display
        time_frame = tk.Frame(time_body_frame, bg='white')
        time_frame.grid(column=0, row=1)
        # ----------------------------------------------------------------------
        # Minutes counter to show the minutes
        minutes_count = tk.Label(time_frame, textvariable=self.minutes,
                                 bg='white', fg=self.warning_color, width=2, font='matura 13 bold')
        minutes_count.grid(ipady=6, column=0, row=0)
        # Minutes Label
        minutes_label = tk.Label(time_frame, text='Min',
                                 bg='white', fg=self.warning_color, width=3, font='matura 13 bold')
        minutes_label.grid(ipady=6, column=1, row=0)
        # add a separator
        time_separator = tk.Label(time_frame, text=':',
                                  bg='white', fg=self.warning_color, height=2, font='matura 13 bold')
        time_separator.grid(column=2, row=0)
        # The seconds counter to show the seconds
        seconds_count = tk.Label(time_frame, textvariable=self.seconds,
                                 bg='white', fg=self.warning_color, width=2, font='matura 13 bold')
        seconds_count.grid(ipady=6, column=3, row=0)
        # show the Sec label
        seconds_label = tk.Label(time_frame, text='Sec',
                                 bg='white', fg=self.warning_color, width=3, font='matura 13 bold')
        seconds_label.grid(ipady=6, column=4, row=0)
        # ------------------------------------------------------------
        heading = tk.Label(right_frame, text='Questions Index',
                           bg='#336699', fg='white', width=18, font='matura 16')
        heading.grid(ipadx=4)
        # create a scrollable frame from the pmw widgets
        scroll_frame = Pmw.ScrolledFrame(right_frame, labelpos=None,
                                         hscrollmode='none',
                                         vscrollmode='dynamic', usehullsize=1,
                                         hull_width=320, hull_height=411)
        scroll_frame.grid()
        interior_frame = scroll_frame.interior()
        inner_frame = tk.Frame(interior_frame, bg='#3399CC')
        inner_frame.grid(ipadx=20)
        column_index = 0
        row_index = 0
        for index, number in enumerate(range(1, len(questions) + 1)):
            if number in self.answers_dict.keys():
                if self.answers_dict.get(number) == '.':
                    bg = None
                    fg = None
                else:
                    bg = "#336699"
                    fg = 'white'
            else:
                bg = None
                fg = None

            if number == self.init_id:
                bg = "red"
                fg = 'white'
            # print(bg, fg)
            buttons = tk.Button(inner_frame, text=number, cursor='hand2',
                                width=2, bg=bg, fg=fg, relief='flat',
                                command=lambda x=number: self.change_question(x)
                                )
            buttons.grid(row=row_index, column=column_index, pady=20, padx=10)
            column_index += 1
            if index == 3:
                row_index += 1
                column_index = 0
            elif index == 7:
                row_index += 1
                column_index = 0
            elif index == 11:
                row_index += 1
                column_index = 0
            elif index == 15:
                row_index += 1
                column_index = 0
            elif index == 19:
                row_index += 1
                column_index = 0

            # print(row_index, column_index)


root = tk.Tk()  # instantiate the tk root window

if __name__ == '__main__':
    MainUi(root)
    import profile

    profile.run('root.mainloop()')
