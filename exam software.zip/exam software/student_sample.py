import os.path

students = {
    'nsu/nas/cmp/16/001': {
        'name': 'Dama Williams Yohanna',
        'level': '400',
        'address': 'High Court, Keffi',
        'image': os.path.join(os.getcwd(), 'assets', 'willy.png')
    },
    'nsu/nas/cmp/16/002': {
        'name': 'Dama Michael Yohanna',
        'level': '100',
        'address': 'High Court, Keffi',
        'image': os.path.join(os.getcwd(), 'assets', 'mike.jpg')
    }
}
